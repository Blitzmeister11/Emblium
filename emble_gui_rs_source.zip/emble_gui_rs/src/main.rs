use emble_gui_rs::board;
use emble_gui_rs::uci_engine;

use std::cell::RefCell;
use std::rc::Rc;

use fltk::app;
use fltk::browser::HoldBrowser;
use fltk::button::Button;
use fltk::dialog;
use fltk::enums::{Align, Event, FrameType};
use fltk::frame::Frame;
use fltk::group::Pack;
use fltk::menu::Choice;
use fltk::misc::Progress;
use fltk::prelude::*;
use fltk::text::{TextBuffer, TextDisplay};
use fltk::window::Window;

use board::BoardState;
use shakmaty::Position;
use uci_engine::{EngineEvent, UciEngine};

const HUMAN_MOVE_TIME_MS: u32 = 1000;

struct AppState {
    board: BoardState,
    engine: Option<UciEngine>,
    human_is_white: bool,
    waiting_for_engine: bool,
    game_over: bool,
}

impl AppState {
    fn new() -> Self {
        AppState {
            board: BoardState::new(),
            engine: None,
            human_is_white: true,
            waiting_for_engine: false,
            game_over: false,
        }
    }
}

fn main() {
    let app = app::App::default();
    let mut win = Window::new(100, 100, 1050, 700, "Emble GUI");

    let state = Rc::new(RefCell::new(AppState::new()));

    // ---------- Board (links) ----------
    let mut board_frame = Frame::new(20, 20, 600, 600, "");
    board_frame.set_frame(FrameType::FlatBox);

    // ---------- Seitenpanel (rechts) ----------
    let mut side = Pack::new(640, 20, 390, 660, "");
    side.set_spacing(8);

    let mut load_engine_btn = Button::new(0, 0, 390, 30, "Engine laden...");
    let mut engine_status = Frame::new(0, 0, 390, 24, "Keine Engine geladen");
    engine_status.set_align(Align::Left | Align::Inside);

    let mut color_choice = Choice::new(0, 0, 390, 28, "");
    color_choice.add_choice("Mensch spielt Weiß");
    color_choice.add_choice("Mensch spielt Schwarz");
    color_choice.set_value(0);

    let mut new_game_btn = Button::new(0, 0, 390, 30, "Neue Partie");
    let mut flip_btn = Button::new(0, 0, 390, 30, "Brett drehen");
    let mut tournament_btn = Button::new(0, 0, 390, 30, "Turnier & SPRT öffnen...");

    let eval_label = Frame::new(0, 0, 390, 20, "Eval (Bauerneinheiten, Sicht Weiß):");
    let mut eval_bar = Progress::new(0, 0, 390, 24, "");
    eval_bar.set_minimum(-1000.0);
    eval_bar.set_maximum(1000.0);
    eval_bar.set_value(0.0);
    eval_bar.set_label("0.00");

    let move_list_label = Frame::new(0, 0, 390, 20, "Zugliste:");
    let move_list = HoldBrowser::new(0, 0, 390, 160, "");

    let output_label = Frame::new(0, 0, 390, 20, "Engine-Ausgabe:");
    let mut engine_output = TextDisplay::new(0, 0, 390, 260, "");
    let output_buffer = TextBuffer::default();
    engine_output.set_buffer(output_buffer.clone());

    side.end();
    win.end();
    win.show();

    board_frame.set_color(fltk::enums::Color::Black);

    // ---------- Zeichnen ----------
    {
        let state = state.clone();
        board_frame.draw(move |f| {
            let st = state.borrow();
            st.board.draw(f.x(), f.y(), f.w(), f.h());
        });
    }

    // ---------- Klick-Handling ----------
    {
        let state = state.clone();
        let mut move_list_h = move_list.clone();
        let mut board_frame_h = board_frame.clone();
        board_frame.handle(move |f, ev| {
            if ev == Event::Push {
                let (mx, my) = app::event_coords();
                let size = f.w().min(f.h());
                let square_size = size / 8;
                let mut st = state.borrow_mut();
                if let Some(sq) = st.board.square_at_pixel(mx, my, f.x(), f.y(), square_size) {
                    if !st.waiting_for_engine && !st.game_over {
                        if let Some(_mv) = st.board.handle_click(sq) {
                            refresh_move_list(&st.board, &mut move_list_h);
                            check_game_over(&mut st);
                            if !st.game_over {
                                request_engine_move(&mut st);
                            }
                        }
                    }
                }
                drop(st);
                f.redraw();
                board_frame_h.redraw();
                true
            } else {
                false
            }
        });
    }

    // ---------- Engine laden ----------
    {
        let state = state.clone();
        let mut engine_status_h = engine_status.clone();
        load_engine_btn.set_callback(move |_| {
            let mut chooser = dialog::FileChooser::new(
                ".",
                "*",
                dialog::FileChooserType::Single,
                "UCI-Engine auswählen",
            );
            chooser.show();
            while chooser.shown() {
                app::wait();
            }
            if let Some(path) = chooser.value(1) {
                match UciEngine::start(&path) {
                    Ok(engine) => {
                        let mut st = state.borrow_mut();
                        st.engine = Some(engine);
                        engine_status_h.set_label(&format!("Lade: {path} ..."));
                    }
                    Err(e) => {
                        dialog::alert_default(&format!("Engine konnte nicht gestartet werden:\n{e}"));
                    }
                }
            }
        });
    }

    // ---------- Farbwahl ----------
    {
        let state = state.clone();
        color_choice.set_callback(move |c| {
            let mut st = state.borrow_mut();
            st.human_is_white = c.value() == 0;
        });
    }

    // ---------- Neue Partie ----------
    {
        let state = state.clone();
        let mut move_list_h = move_list.clone();
        let mut board_frame_h = board_frame.clone();
        let mut eval_bar_h = eval_bar.clone();
        new_game_btn.set_callback(move |_| {
            let mut st = state.borrow_mut();
            st.board.reset();
            st.game_over = false;
            move_list_h.clear();
            eval_bar_h.set_value(0.0);
            eval_bar_h.set_label("0.00");
            if let Some(engine) = st.engine.as_mut() {
                let _ = engine.new_game();
            }
            let human_white = st.human_is_white;
            if !human_white {
                request_engine_move(&mut st);
            }
            drop(st);
            board_frame_h.redraw();
        });
    }

    // ---------- Brett drehen ----------
    {
        let state = state.clone();
        let mut board_frame_h = board_frame.clone();
        flip_btn.set_callback(move |_| {
            state.borrow_mut().board.flipped ^= true;
            board_frame_h.redraw();
        });
    }

    // ---------- Turnier-/SPRT-Fenster öffnen ----------
    {
        tournament_btn.set_callback(move |_| {
            emble_gui_rs::tournament_window::open_tournament_window();
        });
    }

    // ---------- Engine-Events pollen (alle 50ms) ----------
    {
        let state = state.clone();
        let mut move_list_h = move_list.clone();
        let mut board_frame_h = board_frame.clone();
        let mut eval_bar_h = eval_bar.clone();
        let mut engine_status_h = engine_status.clone();
        let mut output_buffer_h = output_buffer.clone();

        app::add_timeout3(0.05, move |handle| {
            {
                let mut st = state.borrow_mut();
                let mut events: Vec<EngineEvent> = Vec::new();
                if let Some(engine) = st.engine.as_ref() {
                    while let Ok(ev) = engine.events.try_recv() {
                        events.push(ev);
                    }
                }
                for ev in events {
                    match ev {
                        EngineEvent::RawLine(line) => {
                            output_buffer_h.append(&line);
                            output_buffer_h.append("\n");
                        }
                        EngineEvent::Ready => {
                            engine_status_h.set_label("Engine bereit");
                        }
                        EngineEvent::IdName(name) => {
                            engine_status_h.set_label(&format!("Geladen: {name}"));
                        }
                        EngineEvent::IdAuthor(_) => {}
                        EngineEvent::Info(info) => {
                            if let Some(cp) = info.score_cp {
                                let mut pawns = cp as f64 / 100.0;
                                if st.board.position.turn() == shakmaty::Color::Black {
                                    pawns = -pawns;
                                }
                                eval_bar_h.set_value((pawns * 100.0).clamp(-1000.0, 1000.0));
                                eval_bar_h.set_label(&format!("{pawns:+.2}"));
                            } else if let Some(mate) = info.score_mate {
                                eval_bar_h.set_label(&format!("Matt in {}", mate.abs()));
                            }
                        }
                        EngineEvent::BestMove { best, ponder: _ } => {
                            if best != "(none)" {
                                if let Err(e) = st.board.push_uci(&best) {
                                    output_buffer_h.append(&format!("[GUI-Fehler] {e}\n"));
                                }
                                refresh_move_list(&st.board, &mut move_list_h);
                            }
                            st.waiting_for_engine = false;
                            check_game_over(&mut st);
                            board_frame_h.redraw();
                        }
                        EngineEvent::Crashed(msg) => {
                            engine_status_h.set_label("Engine abgestürzt");
                            output_buffer_h.append(&format!("[Absturz] {msg}\n"));
                        }
                    }
                }
            }
            app::repeat_timeout3(0.05, handle);
        });
    }

    // Referenzen am Leben halten, die nur in Closures verwendet werden
    let _keep = (eval_label, move_list_label, output_label, color_choice.clone());

    app.run().unwrap();
}

fn refresh_move_list(board: &BoardState, list: &mut HoldBrowser) {
    list.clear();
    let uci_moves = board.uci_history();
    let mut line = String::new();
    for (i, mv) in uci_moves.iter().enumerate() {
        if i % 2 == 0 {
            line = format!("{}. {}", i / 2 + 1, mv);
        } else {
            line = format!("{line}   {mv}");
            list.add(&line);
            line.clear();
        }
    }
    if !line.is_empty() {
        list.add(&line);
    }
    list.bottom_line(list.size());
}

fn check_game_over(st: &mut AppState) {
    if let Some(msg) = st.board.game_over_message() {
        st.game_over = true;
        dialog::message_default(&msg);
    }
}

fn request_engine_move(st: &mut AppState) {
    let Some(engine) = st.engine.as_mut() else { return };
    st.waiting_for_engine = true;
    let moves = st.board.uci_history();
    let _ = engine.set_position(&moves);
    let _ = engine.go_movetime(HUMAN_MOVE_TIME_MS);
}
